#include <iostream>

using namespace std;

#include "nfl.h"

double nfl::salPerGame()
{
    return salary/16 ;
}