#include <iostream>

using namespace std;

#include "epl.h"

double epl::salPerGame()
{
    return salary/38 ;
}