#include <iostream>

using namespace std;

#include "mlb.h"

double mlb::salPerGame()
{
    return salary/162 ;
}