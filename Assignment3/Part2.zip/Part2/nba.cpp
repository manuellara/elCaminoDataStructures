#include <iostream>

using namespace std;

#include "nba.h"

double nba::salPerGame()
{
    return salary/81 ;
}