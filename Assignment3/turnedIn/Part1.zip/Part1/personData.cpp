#include <iostream>

using namespace std;

#include "personData.h"

//////////setter & getter for firstName
void personData::setFirstName( string firstName )
{
    firstName = firstName;
}
string personData::getFirstName()
{
    return firstName; 
} 

//////////setter & getter for lastName
void personData::setLastName( string lastName )
{
    lastName = lastName;
}
string personData::getLastName()
{
    return lastName; 
} 

//////////setter & getter for address
void personData::setAddress( string address )
{
    address = address;
}
string personData::getAddress()
{
    return address; 
} 

//////////setter & getter for city
void personData::setCity( string city )
{
    city = city;
}
string personData::getCity()
{
    return city; 
} 

//////////setter & getter for state
void personData::setState( string state )
{
    state = state;
}
string personData::getState()
{
    return state; 
} 

//////////setter & getter for zip
void personData::setZip( string zip )
{
    zip = zip;
}
string personData::getZip()
{
    return zip; 
} 

//////////setter & getter for phone number 
void personData::setPhoneNumber( string phoneNumber )
{
    phoneNumber = phoneNumber;
}
string personData::getPhoneNumber()
{
    return phoneNumber; 
} 